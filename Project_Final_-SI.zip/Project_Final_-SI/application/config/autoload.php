<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$autoload['packages'] = array();


$autoload['libraries'] = array('database','session');


$autoload['drivers'] = array();


$autoload['helper'] = array('url','file');


$autoload['config'] = array();


$autoload['language'] = array();

model'] = array('first_model' => 'first');

$autoload['model'] = array();
