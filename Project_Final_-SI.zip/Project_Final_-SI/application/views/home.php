<center>
<img src="gambar/logo.png" style="width: 400px; height: 300px;" />
    <div class="welcome-text">
		<h2>Gaji Karyawan</h2>    </div>
    <table>
			<tr>
				
				<td>
					<center>
						<h3>PT. Sinar Metrindo Perkasa (SIMETRI)</h3>
					<h5>Rukan Aries Niaga Blok A1 No 3A dan 3B Jl. Taman Aries no telp (021) 58906959, faks  (021) 58907350.</h5>
					</center>
				</td>
			</tr>
		</table>
    </center>